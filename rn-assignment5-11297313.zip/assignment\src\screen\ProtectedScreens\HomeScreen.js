import { StyleSheet, Text, View } from 'react-native';
import { FontAwesome, EvilIcons, MaterialCommunityIcons, AntDesign, Entypo, Octicons } from '@expo/vector-icons';
import React from 'react'
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

const HomeScreen = () => {
  return (
    <View style={{flex: 1, backgroundColor: "white"}}>
      <View style={{flexDirection: 'row', alignItems: 'center', marginTop: 40, justifyContent: 'space-between', marginHorizontal: 10}}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <FontAwesome name="user-circle-o" style={{marginRight: 4}} size={50} color="black" />
          <View>
            <Text style={{color: "gray"}}>Welcome back</Text>
            <Text style={{fontSize: 25, marginTop: 3}}>Eric Atsu</Text>
          </View>
        </View>
        <View style={{height: 50, width: 50, backgroundColor: "#EEEE", borderRadius: 40, alignItems: 'center', justifyContent: 'center'}}>
          <EvilIcons name="search" size={24} color="black" />
        </View>
      </View>
      <View style={{alignItems: 'center', marginTop: 30}}>
        <View style={{ backgroundColor: '#0C1844', width: '90%', height: 250, padding: 20, borderRadius: 30}}>
          <View style={{alignItems: "center", flexDirection: 'row', justifyContent: 'space-between'}}>
            <MaterialCommunityIcons name="sim-outline" size={24} color="gray" />
            <AntDesign name="wifi" size={24} color="gray" />
          </View>
          <View style={{alignItems: 'center'}}>
            <Text style={{color: 'white', fontSize: 37}}>4562 3737 3804 3840</Text>
          </View>
          <Text style={{color: 'white', marginVertical: 30}}>AR Joson</Text>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <View style={{flexDirection: 'row'}}>
                <View style={{marginRight: 20}}>
                    <Text style={{color: 'gray'}}>Expiry Date</Text>
                    <Text style={{color: 'white'}}>24/2000</Text>
                </View>
                <View>
                    <Text style={{color: 'gray'}}>cvv</Text>
                    <Text style={{color: 'white'}}>6986</Text>
                </View>
            </View>
            <View>
                <Text style={{color: 'gray'}}>cvv</Text>
                <Text style={{color: 'white'}}>Mastercard</Text>
            </View>
        </View>
        </View>
        <View style={{flexDirection: 'row', gap: 40, marginVertical: 10}}>
        <View style={{alignItems: 'center', justifyContent: "center"}}>
          <View style={{backgroundColor: '#EEEE', padding: 20, borderRadius: 40}}>
            <AntDesign name="arrowup" size={24} color="black" />
          </View>
          <Text>Sent</Text>
        </View>
        <View style={{alignItems: 'center', justifyContent: "center"}}>
          <View style={{backgroundColor: '#EEEE', padding: 20, borderRadius: 40}}>
          <AntDesign name="arrowdown" size={24} color="black" />
          </View>
          <Text>Recieve</Text>
        </View>
        <View style={{alignItems: 'center', justifyContent: "center"}}>
          <View style={{backgroundColor: '#EEEE', padding: 20, borderRadius: 40}}>
          <FontAwesome name="dollar" size={24} color="black" />
          </View>
          <Text>Loan</Text>
        </View>
        <View style={{alignItems: 'center', justifyContent: "center"}}>
          <View style={{backgroundColor: '#EEEE', padding: 20, borderRadius: 40}}>
          <AntDesign name="clouduploado" size={30} color="black" />
          </View>
          <Text>Loan</Text>
        </View>
        </View>
      </View>
      <View style={{gap: 20}}>
        <View style={{ justifyContent: 'space-between', flexDirection: 'row', marginHorizontal: 30}}>
                <Text>Transaction</Text>
                <Text style={{color: 'blue'}}>See all</Text>
        </View>
        <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginHorizontal: 20}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <View style={{alignItems: "center", height: 60, width: 60, borderRadius: 50, justifyContent: 'center', backgroundColor: "#EEEE", marginRight: 20}}>
                    <AntDesign name="apple1" size={24} color="black" />
                </View>
                <View>
                    <Text>Apple Store</Text>
                    <Text style={{color: 'gray'}}>Entertainment</Text>
                </View>
            </View>
            <Text>-$5,3837</Text>
        </View>
        <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginHorizontal: 20}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <View style={{alignItems: "center", height: 60, width: 60, borderRadius: 50, justifyContent: 'center', backgroundColor: "#EEEE", marginRight: 20}}>
                <Entypo name="spotify" size={30} color="green" />
                </View>
                <View>
                    <Text>Spotify</Text>
                    <Text style={{color: 'gray'}}>music</Text>
                </View>
            </View>
            <Text>-$5,3837</Text>
        </View>
        <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginHorizontal: 20}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <View style={{alignItems: "center", height: 60, width: 60, borderRadius: 50, justifyContent: 'center', backgroundColor: "#EEEE", marginRight: 20}}>
                <Octicons name="download" size={24} color="black" />
                </View>
                <View>
                    <Text>Money Transer</Text>
                    <Text style={{color: 'gray'}}>Transaction</Text>
                </View>
            </View>
            <Text>-$5,3837</Text>
        </View>
        <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginHorizontal: 20}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <View style={{alignItems: "center", height: 60, width: 60, borderRadius: 50, justifyContent: 'center', backgroundColor: "#EEEE", marginRight: 20}}>
                    <MaterialCommunityIcons name="cart-outline" size={24} color="red" />
                </View>
                <View>
                    <Text>Grocery</Text>
                    <Text style={{color: 'gray'}}>Shopping</Text>
                </View>
            </View>
            <Text>-$5,3837</Text>
        </View>
      </View>
    </View>
  )
}

export default HomeScreen