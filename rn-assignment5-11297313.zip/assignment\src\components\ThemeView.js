import { View } from 'react-native';
import { useColorScheme } from 'react-native';
import { Colors } from '../constants/Colors';

function getThemeColor(props, colorName) {
    const theme = useColorScheme() ?? 'light';
    const colorFromProps = props[theme];
  
    return colorFromProps || Colors[theme][colorName];
  }

  export function ThemedView({ style, lightColor, darkColor, ...otherProps }) {
    const backgroundColor = getThemeColor({ light: lightColor, dark: darkColor }, 'background');
  
    return (
      <View style={[{ backgroundColor }, style]} {...otherProps} />
    );
  }