import { View, Text } from 'react-native'
import React from 'react'
import { Ionicons } from '@expo/vector-icons';

const SettingScreen = () => {
  return (
    <View style={{flex: 1, backgroundColor: 'white'}}>
        <View style={{marginTop: 50}}>
            <View style={{alignItems: 'center', flexDirection: 'row', paddingVertical: 20, borderBottomWidth: 0.5, borderColor: 'gray', justifyContent: 'space-between', marginHorizontal: 10}}>
                <Text>Language</Text>
                <Ionicons name="chevron-forward-outline" size={24} color="black" />
            </View>
            <View style={{alignItems: 'center', flexDirection: 'row', paddingVertical: 20, borderBottomWidth: 0.5, borderColor: 'gray', justifyContent: 'space-between', marginHorizontal: 10}}>
                <Text>My profile</Text>
                <Ionicons name="chevron-forward-outline" size={24} color="black" />
            </View>
            <View style={{alignItems: 'center', flexDirection: 'row', paddingVertical: 20, borderBottomWidth: 0.5, borderColor: 'gray', justifyContent: 'space-between', marginHorizontal: 10}}>
                <Text>Contact Us</Text>
                <Ionicons name="chevron-forward-outline" size={24} color="black" />
            </View>
            <View style={{alignItems: 'center', flexDirection: 'row', paddingVertical: 20, borderBottomWidth: 0.5, borderColor: 'gray', justifyContent: 'space-between', marginHorizontal: 10}}>
                <Text>Change password</Text>
                <Ionicons name="chevron-forward-outline" size={24} color="black" />
            </View>
            <View style={{alignItems: 'center', flexDirection: 'row', paddingVertical: 20, borderBottomWidth: 0.5, borderColor: 'gray', justifyContent: 'space-between', marginHorizontal: 10}}>
                <Text>privacy policy</Text>
                <Ionicons name="chevron-forward-outline" size={24} color="black" />
            </View>
        </View>
        <View style={{marginTop: 80}}>
            <Text style={{fontSize: 30, fontWeight: '700'}}>Theme</Text>
        </View>
    </View>
  )
}

export default SettingScreen