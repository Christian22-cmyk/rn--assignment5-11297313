import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from '../screen/ProtectedScreens/HomeScreen';
import SettingScreen from '../screen/ProtectedScreens/SettingScreen';
import { Ionicons } from '@expo/vector-icons';

 const Tab = createBottomTabNavigator();

export default ProtectedStack = ()=> {
    return <NavigationContainer>
    <Tab.Navigator screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Home') {
              iconName = focused
                ? 'home'
                : 'home';
            } else if (route.name === 'Settings') {
              iconName = focused ? 'settings-sharp' : 'settings-sharp';
            }
            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: 'tomato',
          tabBarInactiveTintColor: 'gray',
        })}>
      <Tab.Screen name="Home" options={{headerShown: false, tabBarBadge: 3}} component={HomeScreen} />
      <Tab.Screen name="Settings" options={{headerTitleAlign: 'center'}} component={SettingScreen} />
    </Tab.Navigator>
  </NavigationContainer>
}